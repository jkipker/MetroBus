<div class="edgtf-gbm-holder <?php echo esc_attr($space_between_blocks); ?> <?php echo esc_attr($extra_class); ?>">
	<div class="edgtf-gbm-inner">
		<div class="edgtf-gbm-grid-sizer"></div>
		<div class="edgtf-gbm-grid-gutter"></div>
		<?php echo do_shortcode($content); ?>
	</div>
</div>