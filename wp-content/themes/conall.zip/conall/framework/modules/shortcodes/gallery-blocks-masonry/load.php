<?php

require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/gallery-blocks-masonry/gallery-block.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/gallery-blocks-masonry/gallery-block-item.php';