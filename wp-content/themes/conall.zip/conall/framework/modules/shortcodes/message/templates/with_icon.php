<?php
$icon_html = conall_edge_icon_collections()->renderIcon($icon, $icon_pack);
?>
<div class="edgtf-message-icon-holder"><?php print $icon_html; ?></div>