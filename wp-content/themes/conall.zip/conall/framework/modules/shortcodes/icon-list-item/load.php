<?php
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/icon-list-item/icon-list-item.php';
