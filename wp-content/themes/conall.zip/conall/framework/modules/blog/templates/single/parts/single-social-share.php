<?php if($display_social_share){ ?>
	<div class="edgtf-blog-single-share">
		<?php echo conall_edge_get_social_share_html(array('type'=>'list')); ?>
	</div>
<?php } ?>