<div class="clearfix">
	<div class="edgt_column edgtf-column1">
		<div class="edgtf-column-inner">
			<?php if(is_active_sidebar('footer_column_1')) {
				dynamic_sidebar( 'footer_column_1' );
			} ?>
		</div>
	</div>
</div>